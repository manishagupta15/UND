#!/usr/bin/env python
# coding: utf-8

# In[125]:


import numpy as np
num_epochs =10
dataset = [[2,2,0],
	[2,4,0],
	[4,2,0],
	[4,4,0],
	[6,2,1],
	[6,4,1],
	[8,2,1],
	[8,4,1]]

learning_rate=0.4

dim=[[2, 2], [2, 4], [4, 2], [4, 4], [6, 2], [6, 4], [8, 2], [8, 4]]
dataset1 = pd.DataFrame (dataset, columns = ['x','y','labels'])

dim=[[2, 2], [2, 4], [4, 2], [4, 4], [6, 2], [6, 4], [8, 2], [8, 4]]
df_dim = pd.DataFrame (dim, columns = ['x','y'])
labels=[0,0,0,0,1,1,1,1]
labels = pd.DataFrame (labels, columns = ['labels'])

num_dims = df_dim.shape[1]
labels = labels.astype(int)
unique_labels = [0,1]

num_protos = len(unique_labels)
prototypes = np.empty((num_protos, num_dims))
proto_labels = []

    # Initialize relevance matrix.
rel = np.ones((num_dims))/num_dims

#     Initialize prototypes using class means.
for i in unique_labels:
#     class_data = dataset1.loc[labels == i, :]
    class_data = dataset1.loc[dataset1.labels == i, :]
    class_data =class_data[['x','y']]
    # Compute class mean.
    mean = np.mean(class_data, axis=0)

    prototypes[i] = mean
    proto_labels.append(i)
    

for epoch in range(0, num_epochs):
    for fvec, lbl in zip(dim, labels):
         # Compute distance from each prototype to this point
        distances = list(np.sum(np.multiply(np.subtract(fvec, p)**2, rel)) for p in prototypes)
        min_dist_index = distances.index(min(distances))

        # Determine winner prototype.
        winner = prototypes[min_dist_index]
        winner_label = proto_labels[min_dist_index]

        # Push or repel the prototype based on the label.
        if winner_label == lbl:
            sign = 1
        else:
            sign = -1

#         # Update relevance vector.
#         rel = rel - relevance_learning_rate*sign*np.subtract(fvec, winner)

#         # Elements cannot be negative.
#         rel = rel.clip(min=0)

#         # Enforce that rel is unit length.
#         rel = np.divide(rel, np.sum(rel))

        # Update winner prototype
        print(prototypes)
#         prototypes[min_dist_index] = np.add(prototypes[min_dist_index], np.multiply(np.subtract(fvec, winner), 1) * learning_rate * sign)
#         prototypes[min_dist_index] = np.add(prototypes[min_dist_index], np.multiply(np.subtract(fvec, winner), 1) * learning_rate )
#         prototypes[min_dist_index] = np.add(prototypes[min_dist_index], np.multiply(np.subtract(fvec, winner), 1) * learning_rate )
#         prototypes[min_dist_index]= prototypes[min_dist_index]+(np.subtract(fvec, winner)*learning_rate* sign)
        prototypes[min_dist_index]=prototypes[min_dist_index]+(np.subtract(fvec, winner)*learning_rate)


# In[89]:


prototypes


# In[9]:


import numpy as np
X = np.array([[2, 2], [2, 4], [4, 2], [4, 4], [6, 2], [6, 4], [8, 2], [8, 4]])
from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=2)
kmeans.fit(X)
y_kmeans = kmeans.predict(X)
centers = kmeans.cluster_centers_
centers


# In[10]:


import matplotlib.pyplot as plt
import seaborn as sns; sns.set()  # for plot styling
import numpy as np
plt.scatter(X[:, 0], X[:, 1], c=y_kmeans, s=50, cmap='viridis')

centers = kmeans.cluster_centers_


plt.scatter(centers[:, 0], centers[:, 1], c='black', s=200, alpha=0.5);

