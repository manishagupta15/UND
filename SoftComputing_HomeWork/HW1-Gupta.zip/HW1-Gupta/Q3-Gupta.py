#!/usr/bin/env python
# coding: utf-8

# In[12]:


from numpy import asarray
from numpy.random import rand
import pandas as pd
from numpy.random import seed
rs =[]
rs_append=[]
 
# # objective function
def objective(x):
	return 2*(x**2)-2*x
 
# derivative of objective function
def derivative(x):
	return 4*x-2
 
# gradient descent algorithm
def gradient_descent(objective, derivative, n_iter, step_size, momentum):
	solution = 0
	del_x1=0
	x1=0
	fx1=0
	dydx1=0
	change = 0.0
	# run the gradient descent
    
	for i in range(n_iter):
		# calculate gradient
		gradient = derivative(solution)
		# calculate update
		new_change = step_size * gradient + momentum * change
		# take a step
		solution = solution - new_change
		# save the change
		change = new_change
        
		x1=solution
		# evaluate candidate point
		solution_eval = objective(solution)
		fx1=solution_eval
		dydx1=gradient
		del_x1=(-1)*new_change
		# report progress
# 		print('>%d f(%s) = %.5f' % (i, solution, solution_eval))
		rs=[i, x1, fx1,dydx1,del_x1]
		rs_append.append(rs)
        
	return rs_append
 
# seed the pseudo random number generator
seed(4)
# define range for input
# bounds = asarray([[-1.0, 1.0]])
# define the total iterations
n_iter = 65
# define the step size
step_size = 0.2
# define momentum
momentum = 0.8
# perform the gradient descent search with momentum
x1 = gradient_descent(objective, derivative, n_iter, step_size, momentum)
merticscolumns=['i', 'x1', 'fx1','dydx1','del_x1']
MetricsDfx1=pd.DataFrame(x1,columns=merticscolumns)
MetricsDfx1.head(100)

# print('f(%s) = %f' % (best, score))


# #X2
# 

# In[13]:


from numpy import asarray
from numpy.random import rand
import pandas as pd
from numpy.random import seed
rs =[]
rs_append=[]
 
# # objective function


# objective function
def objective(x):
	return (x**2)+x
 
# derivative of objective function
def derivative(x):
	return 2*x+1
 
# gradient descent algorithm
def gradient_descent(objective, derivative, n_iter, step_size, momentum):
	solution = 0
	del_x1=0
	x1=0
	fx1=0
	dydx1=0
	change = 0.0
	# run the gradient descent
    
	for i in range(n_iter):
		# calculate gradient
		gradient = derivative(solution)
		# calculate update
		new_change = step_size * gradient + momentum * change
		# take a step
		solution = solution - new_change
		# save the change
		change = new_change
        
		x1=solution
		# evaluate candidate point
		solution_eval = objective(solution)
		fx1=solution_eval
		dydx1=gradient
		del_x1=(-1)*new_change
		# report progress
# 		print('>%d f(%s) = %.5f' % (i, solution, solution_eval))
		rs=[i, x1, fx1,dydx1,del_x1]
		rs_append.append(rs)
        
	return rs_append
 
# seed the pseudo random number generator
seed(4)
# define range for input
# bounds = asarray([[-1.0, 1.0]])
# define the total iterations
n_iter = 65
# define the step size
step_size = 0.2
# define momentum
momentum = 0.8
# perform the gradient descent search with momentum
x2 = gradient_descent(objective, derivative, n_iter, step_size, momentum)
merticscolumns=['i', 'x2', 'fx2','dydx2','del_x2']
MetricsDfx2=pd.DataFrame(x2,columns=merticscolumns)
MetricsDfx2.head(100)


# In[14]:


MetricsDfx1['x2']=MetricsDfx2['x2']
MetricsDfx1['fx2']=MetricsDfx2['fx2']
MetricsDfx1['dydx2']=MetricsDfx2['del_x2']
MetricsDfx1['f(x1,x2)']=MetricsDfx1['fx1']+MetricsDfx1['fx2']


# In[18]:


pd.set_option('display.max_rows', 100)
MetricsDfx1=MetricsDfx1[['i', 'x1', 'dydx1', 'del_x1', 'x2', 'dydx2', 'f(x1,x2)']]
MetricsDfx1

