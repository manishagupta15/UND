#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
e=0;
Threshold=0
w1=0
w2=0
L=1
epoch=0
x1=[0,0,1,1]
x2=[0,1,0,1]
o=[1,1,0,1]
i=0
rs =[]
rs_append=[]
epoch=0
Change_in_W1=0
Change_in_W2=0
Threshold_change=0


# In[2]:


for j in range(1,6):
    epoch=epoch+1
    for i in range(0,4):
        x_w=x1[i]*w1+x2[i]*w2
        if x_w>=Threshold:
            y=1
        else:
            y=0
        e=abs(o[i]-y)
        if(y!=o[i]):
            Threshold_change=-L*(o[i]-y)
            Change_in_W1=L*((o[i])-y)*x1[i]
            Change_in_W2=L*((o[i])-y)*x2[i]
            Threshold=Threshold+Threshold_change
            w1=w1+Change_in_W1
            w2=w2+Change_in_W2
            e1=e+abs(o[i]-y)
        rs=[epoch,x1[i],x2[i],o[i],x_w,y,e,Threshold_change,Change_in_W1,Change_in_W2,Threshold,w1,w2]
        rs_append.append(rs)
merticscolumns=['Epoch','x1','x2','o','x_w','y','e','Change_in_Threshold','Change_in_W1','Change_in_W2','Threshold','w1','w2']
MetricsDf=pd.DataFrame(rs_append,columns=merticscolumns)
MetricsDf

