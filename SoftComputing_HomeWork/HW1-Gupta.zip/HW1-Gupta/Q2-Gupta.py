#!/usr/bin/env python
# coding: utf-8

# In[11]:


import pandas as pd
import numpy as np
e=0;
Threshold=0
w1=0
w2=0
w3=0
L=1
epoch=0
x1=[0,0,1,1,0,0,1,1]
x2=[0,1,0,1,0,1,0,1]
x3=[0,0,0,0,1,1,1,1]
o=[0,0,0,0,0,0,0,1]
i=0
rs =[]
rs_append=[]
epoch=0
Change_in_W1=0
Change_in_W2=0
Change_in_W3=0
Threshold_change=0

for j in range(1,8):
    epoch=epoch+1
    for i in range(0,8):
        x_w=x1[i]*w1+x2[i]*w2+x3[i]*w3
        if x_w>=Threshold:
            y=1
        else:
            y=0
        e=abs(o[i]-y)
        if(y!=o[i]):
            Threshold_change=-L*(o[i]-y)
            Change_in_W1=L*((o[i])-y)*x1[i]
            Change_in_W2=L*((o[i])-y)*x2[i]
            Change_in_W3=L*((o[i])-y)*x3[i]
            Threshold=Threshold+Threshold_change
            w1=w1+Change_in_W1
            w2=w2+Change_in_W2
            w3=w3+Change_in_W3
            e1=e+abs(o[i]-y)
        rs=[epoch,x1[i],x2[i],x3[i],o[i],x_w,y,e,Threshold_change,Change_in_W1,Change_in_W2,Change_in_W3,Threshold,w1,w2,w3]
        rs_append.append(rs)
merticscolumns=['Epoch','x1','x2','x3','o','x_w','y','e','Change_in_Threshold','Change_in_W1','Change_in_W2','Change_in_W3','Threshold','w1','w2','w3']
MetricsDf=pd.DataFrame(rs_append,columns=merticscolumns)
pd.set_option('display.max_rows', 1000)
MetricsDf.head(100)

